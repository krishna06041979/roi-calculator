import React from 'react';
import {Select, SelectItem} from "@heroui/react";
function InvestmentOption({ investmentOption, deleteInvestmentOption }) {

  const InvestmentOptions = [
  {key: "Cash Investment", label: "Cash Investment"},
  {key: "Fixed interest", label: "Fixed interest"},
  {key: "Shares", label: "Shares"},
  {key: "Managed Funds", label: "Managed Funds"},
  {key: "Exchange Traded Funds (ETFs)", label: "Exchange Traded Funds (ETFs)"},
  {key: "Investment Bonds", label: "Investment Bonds"},
  {key: "Annuities", label: "Annuities"},
  {key: "Listed Investment Companies (LICs)", label: "Listed Investment Companies (LICs)"},
  {key: "Real Estate Investment Trusts (REITs)", label: "Real Estate Investment Trusts (REITs)"},
];

 return (
 <div className="todo-item">
 <Select  label="Select an Investment Option">
        {InvestmentOptions.map((InvestmentOption) => (
          <SelectItem key={InvestmentOption.key}>{InvestmentOption.label}</SelectItem>
        ))}
</Select>
<input

 />

<button onClick={() => deleteInvestmentOption(investmentOption.id)}>
 -
 </button>
 </div>
 );
}
export default InvestmentOption;