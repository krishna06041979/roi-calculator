import {Tabs, Tab, Card, CardBody} from "@heroui/react";
import InvestmentOptionList from './components/investmentoptionlist';
import ROI from './components/roi';
import './App.css';

export default function App() {

  return (
    <div className="flex w-full flex-col">
      <Tabs aria-label="Options">
        <Tab key="Investmentoptions" title="Investment options">
          <Card>
            <CardBody>
             <InvestmentOptionList></InvestmentOptionList>
            </CardBody>
          </Card>
        </Tab>
        <Tab key="ROI" title="ROI">
          <Card>
            <CardBody>
<ROI></ROI>
            </CardBody>
          </Card>
        </Tab>
      </Tabs>
    </div>
  );
}