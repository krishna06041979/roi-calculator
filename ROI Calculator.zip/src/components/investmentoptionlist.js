import React, { useState } from "react";
import InvestmentOption from "./investmentoption";

function InvestmentOptionList() {


 const [investmentOptions,setInvestmentOptions] = useState([
   {
 id: 1,
 investmentoption: 'Cash Investment',
 percentage: "%"
 },
  {
 id: 2,
 investmentoption: 'Fixed interest',
 percentage: "%"
 },
  {
 id: 3,
 investmentoption: 'Shares',
 percentage: "%"
 },
  {
 id: 4,
 investmentoption: 'Managed Funds',
 percentage: "%"
 },
  {
 id: 5,
 investmentoption: 'Exchange Traded Funds (ETFs)',
 percentage: "%"
 },
  {
 id: 6,
 investmentoption: 'Investment Bonds',
 percentage: "%"
 },
  {
 id: 7,
 investmentoption: 'Annuities',
 percentage: "%"
 },
  {
 id: 8,
 investmentoption: 'Listed Investment Companies (LICs)',
 percentage: "%"
 },
  {
 id: 9,
 investmentoption: 'Real Estate Investment Trusts (REITs)',
 percentage: "%"
 }
]);

const [investmentoption,setInvestmentoption] = useState('');

function addInvestmentOption(investmentoption) {
 const newInvestmentoption = {
 id: Date.now(),
 investmentoption,
 percentage: "4.5%"
 };

 setInvestmentOptions([...investmentOptions, newInvestmentoption]);
 setInvestmentoption('');
 }
function deleteInvestmentOption(id) {
   if( investmentOptions.length!==1)
    setInvestmentOptions(investmentOptions.filter(task => task.id !== id));
else{
    alert("can't delete investment Option row if have one ");
}
 }

return (
 <div className="todo-list">
    <span>Investment amount : </span>      <span>10000 </span><br/>
    <span>Available amount : </span>     <span>10000 </span>
 {investmentOptions.map(investmentOption => (
 <InvestmentOption
 key={investmentOption.id} 
 investmentOption={investmentOption}
 deleteInvestmentOption={deleteInvestmentOption}
 />
 ))}
<button onClick={() => addInvestmentOption(investmentoption)}>Add</button>
 </div>
 );
}
export default InvestmentOptionList;

