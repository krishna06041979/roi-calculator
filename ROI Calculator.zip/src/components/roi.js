import React, { useState, useEffect } from "react";
import axios from "axios";

export default function ROI() {

  const [rio, setRoi] = useState([]);

  useEffect(() => {
    const fetchROI = async () => {
      try {
        const response = await axios.get(
          "https://localhost/rois",
        );
        const rois = response.data.map((roi) => ({
          roi: roi.roi, 
          fee: roi.fee,
        }));
        setRoi(rois);
      } catch (error) {
        console.error("Error fetching data: ", error);
      }
    };
    fetchROI();
  }, []);

  return (
    <div>
        <span>Projected Return 1 Year</span>
       <input/>
       <br></br>
       <br></br>
          <span>Total fee</span>
       <input/>
    </div>
  );
}